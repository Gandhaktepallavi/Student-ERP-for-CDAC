package com.cdac.erp.core.repository;

public class LostAndFoundItemRepository {

}
