package com.cdac.erp.feature.lostandfound.dto;

public class LostAndFoundItemRequest {

}
