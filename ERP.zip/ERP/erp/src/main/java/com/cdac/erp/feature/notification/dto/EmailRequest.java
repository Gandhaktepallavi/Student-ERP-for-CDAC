package com.cdac.erp.feature.notification.dto;

public class EmailRequest {

}
