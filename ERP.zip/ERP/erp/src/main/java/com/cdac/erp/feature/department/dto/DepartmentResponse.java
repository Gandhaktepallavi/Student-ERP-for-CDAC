package com.cdac.erp.feature.department.dto;

public class DepartmentResponse {

}
