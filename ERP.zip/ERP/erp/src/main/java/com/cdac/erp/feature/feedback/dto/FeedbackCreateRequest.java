package com.cdac.erp.feature.feedback.dto;

public class FeedbackCreateRequest {

}
